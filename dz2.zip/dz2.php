<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <p>1. Объявить две целочисленные переменные $a и $b и задать им произвольные начальные значения.
        Затем написать скрипт, который работает по следующему принципу:
        Если $a и $b положительные, вывести их разность.
        Если $а и $b отрицательные, вывести их произведение.
        Если $а и $b разных знаков, вывести их сумму.
        Ноль можно считать положительным числом.</p>

    <?php

    $a = -5;
    $b = -1;

    if ($a >= 0 && $b >= 0) {
        echo $a - $b;
    } elseif ($a < 0 && $b < 0) {
        echo $a * $b;
    } else {
        echo $a + $b;
    }

    ?>

    <p>2. Присвоить переменной $а значение в промежутке [0..15]. С помощью оператора
        switch организовать вывод чисел от $a до 15.</p>

    <?php
    $a = rand(0, 15);
    echo "Рандомное число: $a <br>";

    // c помощью оператора switch 
    switch ($a) {
        case 0:
            echo '0 ';
        case 1:
            echo '1 ';
        case 2:
            echo '2 ';
        case 3:
            echo '3 ';
        case 4:
            echo '4 ';
        case 5:
            echo '5 ';
        case 6:
            echo '6 ';
        case 7:
            echo '7 ';
        case 8:
            echo '8 ';
        case 9:
            echo '9 ';
        case 10:
            echo '10 ';
        case 11:
            echo '11 ';
        case 12:
            echo '12 ';
        case 13:
            echo '13 ';
        case 14:
            echo '14 ';
        case 15:
            echo '15 </br>';
    }

    // c помощью рекурсии 
    function writeNumber($a)
    {
        if ($a <= 15) {
            echo "$a ";
            writeNumber($a + 1);
        }
    }

    writeNumber($a);

    ?>

    <p>3.Реализовать основные 4 арифметические операции в виде функций с двумя параметрами.
        Обязательно использовать оператор return.</p>

    <?php

    $a = 1;
    $b = 4;

    function sum($a, $b)
    {
        echo "Cложение " . ($a + $b) . "<br>";
    }

    function computation($a, $b)
    {
        echo "Вычитание " . ($a - $b) . " <br>";
    }

    function multiplication($a, $b)
    {
        echo "Умножение " . ($a * $b) . " <br>";
    }

    function division($a, $b)
    {
        echo "Деление " . ($a / $b) . " <br>";
    }

    sum($a, $b);
    computation($a, $b);
    multiplication($a, $b);
    division($a, $b);

    ?>

    <p>4. Реализовать функцию с тремя параметрами: function mathOperation($arg1, $arg2, $operation),
        где $arg1, $arg2 – значения аргументов, $operation – строка с названием операции.
        В зависимости от переданного значения операции выполнить одну из арифметических операций (использовать функции из пункта 3)
        и вернуть полученное значение (использовать switch). </p>

    <?php

    function mathOperation($arg1, $arg2, $operation)
    {
        switch ($operation) {
            case 'sum':
                return sum($arg1, $arg2);
                break;
            case 'computation':
                return computation($arg1, $arg2);
                break;
            case 'multiplication':
                multiplication($arg1, $arg2);
                break;
            case 'divison':
                division($arg1, $arg2);
                break;
        }
    }

    echo mathOperation(10, 5, 'sum');
    echo mathOperation(10, 5, 'computation');
    echo mathOperation(10, 5, 'multiplication');
    echo mathOperation(10, 5, 'divison');

    ?>


    <p>5. Посмотреть на встроенные функции PHP.
        Используя имеющийся HTML шаблон, вывести текущий год в подвале при помощи встроенных функций PHP.</p>

    Выполнено в файле z5.php

    <p>6. С помощью рекурсии организовать функцию возведения числа в степень.
        Формат: function power($val, $pow), где $val – заданное число, $pow – степень.</p>

    <?php

    $val = rand(1, 5);
    $pow = rand(0, 10);
    echo 'Случайное число: ' . $val . '<br>';
    echo 'Возводим в степень: ' . $pow . '<br>';

    function power($val, $pow)
    {
        if ($pow !== 0) {
            return $val * power($val, $pow - 1);
        }
        return 1;
    }

    echo 'Получаем: ' . power($val, $pow);

    ?>


    <p>7. Написать функцию, которая вычисляет текущее время и возвращает его в формате с правильными склонениями, например: 22 часа 15 минут, 21 час 43 минуты.</p>

    <?php

    $h = date('G'); // 	Часы в 24-часовом формате без ведущего нуля	от 0 до 23
    $m = date('i'); //  Минуты с ведущим нулём
    (string)$currH; // current hour 
    (string)$currM; // current minutes 

    if ($h==1 || $h==21){
        $currH = "$h час";
    }elseif($h==2 || $h==3 || $h==4 || $h==22 || $h==23){
        $currH = "$h часа";
    }else{
        $currH = "$h часов";
    }

    if ($m==1 || $m==21 || $m==31 || $m==41 || $m==51){
        $currM = "$i минута";
    }elseif($h==2 || $h==3 || $h==4 || 
            $h==22 || $h==23 || $h==24 || 
            $h==32 || $h==33 || $h==34 || 
            $h==42 || $h==43 || $h==44 ||
            $h==52 || $h==53 || $h==54){
        $currM = "$h минуты";
    }else{
        $currM = "$h минут";
    }

    echo "Текушее  время: $currH $currM";

    ?>





</body>

</html>