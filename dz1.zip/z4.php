<?php
    $title = "Time To Shine";
    $greeting = "<h1>Greetings! We're glad to see you on our website.</h1>";
    $currentYear = 2021;
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="style/style.css" type="text/css">
</head>

<body>
    <div class="container">
        <div class="header">
            <img src="foto/logo.png" height="40">
            <ul class="menu">
                <li><a href="contacts.html">Contacts</a></li>
                <li><a href="catalog.html">Catalog</a></li>
                <li><a href="#">Main</a></li>
            </ul>
        </div>
    </div>
    <h1 class="name"><i>Jewellery  from <q><?= $title ?></q></i></h1>
    <div class="body">
        <p><?= $greeting ?><br>
            Choose what is more suitable for you in our spring-summer collection <?= $currentYear ?></p>
        <img src="foto/bril.GIF" height="500">
    </div>
    <div class="footer">All rights reserved &copy; Yuliya Molakava</div>
</body>

</html>